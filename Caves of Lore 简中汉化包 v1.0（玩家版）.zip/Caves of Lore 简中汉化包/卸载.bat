@echo off
setlocal
title Caves of Lore ���к��� v1.0 - ж�ػ�ԭ
rem ============================================================
rem  ���ļ����� GBK��������Ϊ UTF-8����� chcp 65001��
rem  ���̣���λ��ϷĿ¼ - �汾ָ��У�� - ����ԭ�ļ�Ϊ *.l10nbak - ���ǡ�
rem ============================================================

set "SRC=%~dp0Caves of Lore_Data"
set "DST=%~dp0.."
if exist "%~dp0..\Caves of Lore.exe" set "DST=%~dp0.."
if exist "%DST%\Caves of Lore.exe" goto FOUND
set "DST=%~dp0"
if exist "%DST%\Caves of Lore.exe" goto FOUND
goto NODIR
:FOUND



echo ============================================
echo    Caves of Lore ���к��� v1.0  ж�ػ�ԭ
echo    ��ϷĿ¼��%DST%
echo ============================================
echo.
echo  ������ 43 ���ļ���ԭ�ļ�����Ϊ *.l10nbak������ж��.batһ����ԭ��
echo  ���������ʼ
pause >nul
set "F=%DST%\Caves of Lore_Data\Managed\Assembly-CSharp.dll"
if not exist "%F%.l10nbak" goto SKIP_0
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ Managed\Assembly-CSharp.dll
:SKIP_0
set "F=%DST%\Caves of Lore_Data\Managed\CavesL10N.dll"
if not exist "%F%" goto SKIP_1
del "%F%" >nul
echo   �Ƴ� Managed\CavesL10N.dll
:SKIP_1
set "F=%DST%\Caves of Lore_Data\Managed\CavesL10N.table.txt"
if not exist "%F%" goto SKIP_2
del "%F%" >nul
echo   �Ƴ� Managed\CavesL10N.table.txt
:SKIP_2
set "F=%DST%\Caves of Lore_Data\level0"
if not exist "%F%.l10nbak" goto SKIP_3
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level0
:SKIP_3
set "F=%DST%\Caves of Lore_Data\level1"
if not exist "%F%.l10nbak" goto SKIP_4
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level1
:SKIP_4
set "F=%DST%\Caves of Lore_Data\level10"
if not exist "%F%.l10nbak" goto SKIP_5
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level10
:SKIP_5
set "F=%DST%\Caves of Lore_Data\level11"
if not exist "%F%.l10nbak" goto SKIP_6
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level11
:SKIP_6
set "F=%DST%\Caves of Lore_Data\level12"
if not exist "%F%.l10nbak" goto SKIP_7
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level12
:SKIP_7
set "F=%DST%\Caves of Lore_Data\level13"
if not exist "%F%.l10nbak" goto SKIP_8
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level13
:SKIP_8
set "F=%DST%\Caves of Lore_Data\level14"
if not exist "%F%.l10nbak" goto SKIP_9
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level14
:SKIP_9
set "F=%DST%\Caves of Lore_Data\level15"
if not exist "%F%.l10nbak" goto SKIP_10
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level15
:SKIP_10
set "F=%DST%\Caves of Lore_Data\level16"
if not exist "%F%.l10nbak" goto SKIP_11
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level16
:SKIP_11
set "F=%DST%\Caves of Lore_Data\level17"
if not exist "%F%.l10nbak" goto SKIP_12
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level17
:SKIP_12
set "F=%DST%\Caves of Lore_Data\level18"
if not exist "%F%.l10nbak" goto SKIP_13
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level18
:SKIP_13
set "F=%DST%\Caves of Lore_Data\level19"
if not exist "%F%.l10nbak" goto SKIP_14
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level19
:SKIP_14
set "F=%DST%\Caves of Lore_Data\level2"
if not exist "%F%.l10nbak" goto SKIP_15
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level2
:SKIP_15
set "F=%DST%\Caves of Lore_Data\level20"
if not exist "%F%.l10nbak" goto SKIP_16
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level20
:SKIP_16
set "F=%DST%\Caves of Lore_Data\level21"
if not exist "%F%.l10nbak" goto SKIP_17
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level21
:SKIP_17
set "F=%DST%\Caves of Lore_Data\level22"
if not exist "%F%.l10nbak" goto SKIP_18
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level22
:SKIP_18
set "F=%DST%\Caves of Lore_Data\level23"
if not exist "%F%.l10nbak" goto SKIP_19
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level23
:SKIP_19
set "F=%DST%\Caves of Lore_Data\level3"
if not exist "%F%.l10nbak" goto SKIP_20
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level3
:SKIP_20
set "F=%DST%\Caves of Lore_Data\level4"
if not exist "%F%.l10nbak" goto SKIP_21
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level4
:SKIP_21
set "F=%DST%\Caves of Lore_Data\level5"
if not exist "%F%.l10nbak" goto SKIP_22
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level5
:SKIP_22
set "F=%DST%\Caves of Lore_Data\level6"
if not exist "%F%.l10nbak" goto SKIP_23
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level6
:SKIP_23
set "F=%DST%\Caves of Lore_Data\level7"
if not exist "%F%.l10nbak" goto SKIP_24
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level7
:SKIP_24
set "F=%DST%\Caves of Lore_Data\level8"
if not exist "%F%.l10nbak" goto SKIP_25
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level8
:SKIP_25
set "F=%DST%\Caves of Lore_Data\level9"
if not exist "%F%.l10nbak" goto SKIP_26
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ level9
:SKIP_26
set "F=%DST%\Caves of Lore_Data\resources.assets"
if not exist "%F%.l10nbak" goto SKIP_27
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ resources.assets
:SKIP_27
set "F=%DST%\Caves of Lore_Data\sharedassets0.assets"
if not exist "%F%.l10nbak" goto SKIP_28
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets0.assets
:SKIP_28
set "F=%DST%\Caves of Lore_Data\sharedassets1.assets"
if not exist "%F%.l10nbak" goto SKIP_29
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets1.assets
:SKIP_29
set "F=%DST%\Caves of Lore_Data\sharedassets12.assets"
if not exist "%F%.l10nbak" goto SKIP_30
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets12.assets
:SKIP_30
set "F=%DST%\Caves of Lore_Data\sharedassets13.assets"
if not exist "%F%.l10nbak" goto SKIP_31
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets13.assets
:SKIP_31
set "F=%DST%\Caves of Lore_Data\sharedassets16.assets"
if not exist "%F%.l10nbak" goto SKIP_32
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets16.assets
:SKIP_32
set "F=%DST%\Caves of Lore_Data\sharedassets17.assets"
if not exist "%F%.l10nbak" goto SKIP_33
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets17.assets
:SKIP_33
set "F=%DST%\Caves of Lore_Data\sharedassets18.assets"
if not exist "%F%.l10nbak" goto SKIP_34
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets18.assets
:SKIP_34
set "F=%DST%\Caves of Lore_Data\sharedassets19.assets"
if not exist "%F%.l10nbak" goto SKIP_35
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets19.assets
:SKIP_35
set "F=%DST%\Caves of Lore_Data\sharedassets20.assets"
if not exist "%F%.l10nbak" goto SKIP_36
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets20.assets
:SKIP_36
set "F=%DST%\Caves of Lore_Data\sharedassets21.assets"
if not exist "%F%.l10nbak" goto SKIP_37
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets21.assets
:SKIP_37
set "F=%DST%\Caves of Lore_Data\sharedassets22.assets"
if not exist "%F%.l10nbak" goto SKIP_38
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets22.assets
:SKIP_38
set "F=%DST%\Caves of Lore_Data\sharedassets5.assets"
if not exist "%F%.l10nbak" goto SKIP_39
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets5.assets
:SKIP_39
set "F=%DST%\Caves of Lore_Data\sharedassets6.assets"
if not exist "%F%.l10nbak" goto SKIP_40
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets6.assets
:SKIP_40
set "F=%DST%\Caves of Lore_Data\sharedassets7.assets"
if not exist "%F%.l10nbak" goto SKIP_41
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets7.assets
:SKIP_41
set "F=%DST%\Caves of Lore_Data\sharedassets8.assets"
if not exist "%F%.l10nbak" goto SKIP_42
copy /y "%F%.l10nbak" "%F%" >nul
del "%F%.l10nbak" >nul
echo   ��ԭ sharedassets8.assets
:SKIP_42
echo.
echo  ��ԭ��ɣ���Ϸ�ѻָ�ԭ�棨δ��װ�����ļ��Զ���������
pause
goto :eof

:MISS_FILE
echo ������ϷĿ¼ȱ��Ԥ���ļ���%F%
pause
goto :eof

:NODIR
echo ����δ�ҵ���ϷĿ¼��Caves of Lore.exe����
echo    ��ѱ��ļ��зŵ���Ϸ��Ŀ¼��������ϷĿ¼ͬ�������С�
pause
goto :eof
