@echo off
setlocal
title Caves of Lore ���к��� v1.0 - ��װ
rem ============================================================
rem  ���ļ����� GBK��������Ϊ UTF-8����� chcp 65001��
rem  ���̣���λ��ϷĿ¼ - �汾ָ��У�� - ����ԭ�ļ�Ϊ *.l10nbak - ���ǡ�
rem ============================================================

set "SRC=%~dp0Caves of Lore_Data"
set "DST=%~dp0.."
if exist "%~dp0..\Caves of Lore.exe" set "DST=%~dp0.."
if exist "%DST%\Caves of Lore.exe" goto FOUND
set "DST=%~dp0"
if exist "%DST%\Caves of Lore.exe" goto FOUND
goto NODIR
:FOUND

for %%A in ("%DST%\Caves of Lore_Data\resources.assets") do set "SZ=%%~zA"
if not exist "%DST%\Caves of Lore_Data\resources.assets" goto NODIR
if exist "%DST%\Caves of Lore_Data\resources.assets.l10nbak" goto SZOK
if "%SZ%"=="34677312" goto SZOK
echo ������Ϸ�汾������resources.assets �ߴ� %SZ%��Ԥ�� 34677312����
echo    ��������ֻ��������֮ƥ���ԭ��汾��ͨ��Ϊ��ǰ Steam ��ʽ�棩��
echo    ��Ϸ���º���ȴ���Ӧ�汾������������ǿ�а�װ��
pause
goto :eof
:SZOK

echo ============================================
echo    Caves of Lore ���к��� v1.0  ��װ
echo    ��ϷĿ¼��%DST%
echo ============================================
echo.
echo  ������ 43 ���ļ���ԭ�ļ�����Ϊ *.l10nbak������ж��.batһ����ԭ��
echo  ���������ʼ
pause >nul
set "F=%DST%\Caves of Lore_Data\Managed\Assembly-CSharp.dll"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\Managed\Assembly-CSharp.dll" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\Managed\CavesL10N.dll"
copy /y "%SRC%\Managed\CavesL10N.dll" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\Managed\CavesL10N.table.txt"
copy /y "%SRC%\Managed\CavesL10N.table.txt" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level0"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level0" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level1"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level1" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level10"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level10" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level11"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level11" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level12"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level12" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level13"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level13" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level14"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level14" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level15"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level15" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level16"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level16" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level17"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level17" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level18"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level18" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level19"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level19" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level2"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level2" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level20"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level20" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level21"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level21" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level22"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level22" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level23"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level23" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level3"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level3" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level4"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level4" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level5"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level5" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level6"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level6" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level7"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level7" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level8"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level8" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\level9"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\level9" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\resources.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\resources.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets0.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets0.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets1.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets1.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets12.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets12.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets13.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets13.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets16.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets16.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets17.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets17.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets18.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets18.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets19.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets19.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets20.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets20.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets21.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets21.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets22.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets22.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets5.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets5.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets6.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets6.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets7.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets7.assets" "%F%" >nul
set "F=%DST%\Caves of Lore_Data\sharedassets8.assets"
if not exist "%F%" goto MISS_FILE
if not exist "%F%.l10nbak" copy /y "%F%" "%F%.l10nbak" >nul
copy /y "%SRC%\sharedassets8.assets" "%F%" >nul
echo.
echo  ��ɣ������� 43 ���ļ���
echo  ������Ϸ���ɣ����˵�/�Ի�/�̳̾�Ϊ�������ģ���
echo  ���軹ԭ��˫�� ж��.bat��
pause
goto :eof

:MISS_FILE
echo ������ϷĿ¼ȱ��Ԥ���ļ���%F%
echo    ��ȷ������������ Caves of Lore ��ϷĿ¼��
pause
goto :eof

:NODIR
echo ����δ�ҵ���ϷĿ¼��Caves of Lore.exe����
echo    ��ѱ��ļ��зŵ���Ϸ��Ŀ¼��������ϷĿ¼ͬ�������С�
echo    �����ȸ���һ����ϷĿ¼���������ԣ���Ҫֱ�Ӹ�ԭ��Ŀ¼��
pause
goto :eof
